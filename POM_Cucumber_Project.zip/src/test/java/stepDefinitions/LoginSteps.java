package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.*;
import pages.LoginPage;
import utilities.BaseClass;

public class LoginSteps {
    WebDriver driver;
    LoginPage login;

    @Given("browser is open")
    public void browser_is_open() {
        BaseClass.initializeBrowser();
        driver = BaseClass.driver;
        driver.get("https://the-internet.herokuapp.com/login");
        login = new LoginPage(driver);
    }

    @When("user enters {string} and {string}")
    public void user_enters_credentials(String uname, String pwd) {
        login.enterUsername(uname);
        login.enterPassword(pwd);
    }

    @And("clicks login button")
    public void clicks_login_button() {
        login.clickLogin();
    }

    @Then("user is navigated to the homepage")
    public void user_is_navigated_to_the_homepage() {
        boolean success = driver.getPageSource().contains("Secure Area");
        Assert.assertTrue(success);
        BaseClass.quitBrowser();
    }
}
